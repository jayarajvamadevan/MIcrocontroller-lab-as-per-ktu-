#include<reg52.h>
void delay(int x);
sbit led1 = P2^0;
sbit led2= P2^1;

void main()
{
	int i=0;
	int j=0;
 while(1)
  {
   for( i=0;i<10;i++)
		{
				
		 led1 = 1; 
     delay(30);
     led1 = 0;
     delay(30);
    }
		for( j=0;j<10;j++)
		{
     led2 = 1; 
     delay(60);
     led2 = 0;
     delay(60);
    }
	}
 
}

void delay(int x)
{
  int i,j;
  for(i=0;i<x;i++)
  {
    for(j=0;j<1000;j++);
  }
}