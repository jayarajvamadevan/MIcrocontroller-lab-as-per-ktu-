#include<reg52.h>
void delay(int x);//prototype function
sbit motor_pin_1 = P2^0;
sbit motor_pin_2 = P2^1;
sbit motor_pin_3 = P2^2;
sbit motor_pin_4 = P2^3;
void main()
{
 while(1)
  {
    motor_pin_1 = 1;
    motor_pin_2 = 0; //Rotates Motor1  Clockwise
    motor_pin_3 = 1;
    motor_pin_4 = 0; //Rotates Motor2  Clockwise
    delay(100);
    motor_pin_1 = 0;
    motor_pin_2 = 0; //Stops Motor1
    motor_pin_3 = 0;
    motor_pin_4 = 0; //Stops Motor2
    delay(100);
    motor_pin_1 = 0;
    motor_pin_2 = 1; //Rotates Motor1 Anticlockwise
    motor_pin_3 = 0;
    motor_pin_4 = 1; //Rotates Motor2 Anticlockwise
    delay(100);
    motor_pin_1 = 0;
    motor_pin_2 = 0; //Stops Motor1
    motor_pin_3 = 0;
    motor_pin_4 = 0; //Stops Motor2
    delay(100);
  }
  
}

void delay(int x)
{
  int i,j;
  for(i=0;i<x;i++)
  {
    for(j=0;j<1000;j++)
    {
    }
  }
}