#include<reg52.h>
void delay(int k);
sbit SW1 =P1^0;
sbit SW2 =P1^1;
sbit SW3 =P1^2;
void main()
{
	while (1)
		{
			if (SW1 == 0)// Wave Drive
				{
				 P2=0x01; //0001
				 delay(100);
				 P2=0x02; //0010
				 delay(100);
				 P2=0x04; //0100
				 delay(100);
				 P2=0x08; //1000
				 delay(100);
				}
			 if (SW2 == 0) // Full Drive
				{
				 P2 = 0x03; //0011
				 delay(1000);
				 P2 = 0x06; //0110
				 delay(1000);
				 P2 = 0x0C; //1100
				 delay(1000);
				 P2 = 0x09; //1001
				 delay(1000);
				}
			 if (SW3 == 0) // Half Drive
				{
				 P2=0x01; //0001
				 delay(1000);
				 P2=0x03; //0011
				 delay(1000);
				 P2=0x02; //0010
				 delay(1000);
				 P2=0x06; //0110
				 delay(1000);
				 P2=0x04; //0100
				 delay(1000);
				 P2=0x0C; //1100
				 delay(1000);
				 P2=0x08; //1000
				 delay(1000);
				 P2=0x09; //1001
				 delay(1000);
				}
	  }
}
void delay(int k)
{
 int i,j;
 for(i=0;i<k;i++)
 {
  for(j=0;j<100;j++)
  {}
 }
}