#include<reg52.h>
sbit ALE = P2^4;
sbit OE = P2^5;
sbit START = P2^6;
sbit EOC = P2^7;
sbit ADDR_A = P2^0;
sbit ADDR_B = P2^1;
sbit ADDR_C = P2^2;
sfr INDATA  = 0x90; //Port P1
sfr OUTDATA = 0xB0; //Port P3
void MSDelay(unsigned int x) 
{
unsigned int i,j;
	for(i=0;i<x;i++)
		{
		for(j=0;j<1000;j++);
		}
}
void main()
{
	unsigned char value;
	INDATA = 0xFF;
	OUTDATA  = 0x00;
	EOC = 1; 
	ALE = 0;
	OE = 0; 
	START = 0;
	while(1)
	{
		ADDR_C = 0;
		ADDR_B = 0;
		ADDR_A = 0;
		MSDelay(2);
		ALE = 1;
		MSDelay(2);
		START = 1;
		MSDelay(1);
		ALE = 0;
		START = 0;
		while(EOC==1);
		while(EOC==0);
		OE=1;
		MSDelay(2);
		value = INDATA;
		OUTDATA = value;
		OE = 0 ;
	}
}