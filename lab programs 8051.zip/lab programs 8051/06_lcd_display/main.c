# include<reg52.h>
sbit RS = P3^0;
sbit RW = P3^1;
sbit EN = P3^2;
sfr PORT2 = 0xA0;//Port P2
void delay_ms(unsigned int k)
{
 unsigned int i,j;
 for(i=0;i<k;i++)
 {
  for(j=0;j<1000;j++)
  {}
 }
}
void lcd_data(unsigned char data1)
{
    PORT2 = data1;
    RS = 1;
    RW = 0;
    EN = 1;
    delay_ms(5);
    EN = 0;
}
void lcd_command(unsigned char cmd)
{
    PORT2 = cmd;
    RS = 0;
    RW = 0;
    EN = 1;
    delay_ms(5);
    EN = 0;
}
void lcd_string(unsigned char string[],unsigned int len)
{
    unsigned int i;
    for(i=0;i<len;i++)
    {
      lcd_data(string[i]); 
    }
}
void lcd_initialize()
{
    lcd_command(0x38);
    lcd_command(0x06);
    lcd_command(0x0C);
    lcd_command(0x01);
}
void main() 
{
		PORT2=0x00;
    lcd_initialize();
    while(1)
    {
      lcd_command(0x80);
      lcd_string("WELCOME TO",10);
      lcd_command(0xC0);
      lcd_string("SBCE PATTOOR",12);
    }
}
