#include<reg52.h>
 sbit RS = P3^0;
 sbit RW = P3^1;
 sbit EN = P3^2;
 sbit C1 = P2^0;
 sbit C2 = P2^1;
 sbit C3 = P2^2;
 sbit C4 = P2^3;
 sbit R1 = P2^4;
 sbit R2 = P2^5;
 sbit R3 = P2^6;
 sbit R4 = P2^7;
sfr PORT1 = 0x90;//Port P1
sfr PORT2 = 0xA0;//Port P2
void delay_ms(unsigned int k)
{
 unsigned int i,j;
 for(i=0;i<k;i++)
 {
  for(j=0;j<100;j++)
  {}
 }
}
void lcd_data(unsigned char data1)
{
    PORT1 = data1;
    RS = 1;
    RW = 0;
    EN = 1;
    delay_ms(5);
    EN = 0;
}
void lcd_command(unsigned char cmd)
{
    PORT1 = cmd;
    RS = 0;
    RW = 0;
    EN = 1;
    delay_ms(5);
    EN = 0;
}
void lcd_string(unsigned char string[],unsigned int len)
{
    unsigned int i;
    for(i=0;i<len;i++)
    {
      lcd_data(string[i]); 
    }
}
void keypad_press()
{
//Colomn 1
    C1=0;C2=1;C3=1;C4=1;
    if(R1==0)
    {
      lcd_data('7');
      while (R1==0);
    }
    if(R2==0)
    {
      lcd_data('4');
      while (R2==0);
    }
    if(R3==0)
    {
      lcd_data('1');
      while (R3==0);
    }
    if(R4==0)
    {
      lcd_data('C');
      while (R4==0);
    }
//Colomn 2
    C1=1;C2=0;C3=1;C4=1;
    if(R1==0)
    {
      lcd_data('8');
      while (R1==0);
    }
    if(R2==0)
    {
      lcd_data('5');
      while (R2==0);
    }
    if(R3==0)
    {
      lcd_data('2');
      while (R3==0);
    }
    if(R4==0)
    {
      lcd_data('0');
      while (R4==0);
    }
//Colomn 3
    C1=1;C2=1;C3=0;C4=1;
    if(R1==0)
    {
      lcd_data('9');
      while (R1==0);
    }
    if(R2==0)
    {
      lcd_data('6');
      while (R2==0);
    }
    if(R3==0)
    {
      lcd_data('3');
      while (R3==0);
    }
    if(R4==0)
    {
      lcd_data('=');
      while (R4==0);
    }
//Colomn 4
    C1=1;C2=1;C3=1;C4=0;
    if(R1==0)
    {
      lcd_data('/');
      while (R1==0);
    }
    if(R2==0)
    {
      lcd_data('X');
      while (R2==0);
    }
    if(R3==0)
    {
      lcd_data('-');
      while (R3==0);
    }
    if(R4==0)
    {
      lcd_data('+');
      while (R4==0);
    }
}
void lcd_initialize()
{
    lcd_command(0x02);
    lcd_command(0x38);
    lcd_command(0x06);
    lcd_command(0x0C);  
    lcd_command(0x01);
}
void main() 
{
    PORT1=0x00;
    PORT2=0xF0;
    lcd_initialize();
    while(1)
    {
      lcd_command(0x80);
      lcd_string("KEY PRESSED IS:",15); 
      lcd_command(0xC0);
      keypad_press();
    }
}
